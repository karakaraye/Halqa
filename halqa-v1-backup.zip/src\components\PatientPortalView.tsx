'use client';

import React, { useState } from 'react';
import { useEpisodes } from '@/context/EpisodeContext';
import {
  CheckCircle2,
  Circle,
  PhoneCall,
  Calendar,
  FileText,
  Globe2,
  Sparkles
} from 'lucide-react';

export const PatientPortalView: React.FC = () => {
  const { episodes, activePatientEpisodeId, setActivePatientEpisodeId } = useEpisodes();
  const activeEpisodeId = activePatientEpisodeId || episodes[0]?.id || '';
  const setActiveEpisodeId = setActivePatientEpisodeId;
  const [lang, setLang] = useState<'ar' | 'en'>('ar');
  const [callbackRequested, setCallbackRequested] = useState(false);

  const currentEp = episodes.find((ep) => ep.id === activeEpisodeId) || episodes[0];

  const content = {
    ar: {
      dir: 'rtl',
      badge: 'بوابة المتابعة الطبية الوقائية',
      greeting: `مرحباً ${currentEp?.patientName || ''}`,
      title: 'خارطة طريق رحلتك الصحية',
      subtitle: 'نحن هنا لنرشدك خطوة بخطوة بكل وضوح وسرية.',
      reassuranceHeader: 'ماذا تعني هذه النتيجة بالنسبة لك؟',
      reassuranceBody:
        'نتائج الفحص الوقائي المبكر ليست تشخيصاً نهائياً بالمرض. الفحص هو خطوة استباقية دورية تعني ببساطة أن فريقك الطبي بحاجة إلى إلقاء نظرة أكثر تفصيلاً للتأكد من سلامتك وتقديم أفضل سبل الوقاية المبكرة.',
      steps: [
        { label: 'إتمام الفحص المبدئي', sub: 'تم تسجيل العينة وتحليلها بنجاح' },
        { label: 'المراجعة الطبية الأولية', sub: 'تواصل المنسق وتحديد الموعد المناسب' },
        { label: 'الاستشارة التخصصية', sub: 'مناقشة الخطة مع الطبيب الاستشاري' },
        { label: 'الفحص التأكيدي الدقيق', sub: 'إجراء الفحص التشخيصي المتقدم' },
        { label: 'اكتمال المتابعة والاطمئنان', sub: 'اعتماد التقرير النهائي وخطة الوقاية الدورية' },
      ],
      btnCallback: 'طلب اتصال هاتفي من منسق الرعاية',
      btnCallbackSuccess: 'تم استلام طلبك! سيتصل بك الممرض خلال 15 دقيقة',
      btnBook: 'تأكيد موعد الاستشارة التخصصية',
      doctorContact: 'طبيبك المسؤول عن متابعة الحالة:',
    },
    en: {
      dir: 'ltr',
      badge: 'Preventive Care Navigation Portal',
      greeting: `Welcome, ${currentEp?.patientName || ''}`,
      title: 'Your Care Journey Roadmap',
      subtitle: 'We are here to guide you step-by-step with complete clarity and privacy.',
      reassuranceHeader: 'What does this result mean for you?',
      reassuranceBody:
        'A preliminary screening finding is NOT a diagnosis of disease. Screening is a proactive routine health checkpoint that simply tells us to take a closer, more detailed look so we can protect your long-term health as early as possible.',
      steps: [
        { label: 'Screening Completed', sub: 'Sample received and analyzed by lab' },
        { label: 'Care Team Outreach', sub: 'Nurse coordinator assigned to your file' },
        { label: 'Specialist Consultation', sub: 'Discuss personalized options with a doctor' },
        { label: 'Diagnostic Confirmation', sub: 'Clear, high-precision follow-up assessment' },
        { label: 'Documented Safe Closure', sub: 'Final results verified; routine wellness plan active' },
      ],
      btnCallback: 'Request a Nurse Coordinator Callback',
      btnCallbackSuccess: 'Callback requested! A care nurse will reach you within 15 minutes',
      btnBook: 'Confirm Specialist Appointment',
      doctorContact: 'Your Accountable Clinician:',
    },
  };

  const t = content[lang];

  // Map case stage to step index (0-4)
  const getActiveStepIndex = () => {
    if (!currentEp) return 0;
    switch (currentEp.stage) {
      case 'INGESTED':
        return 0;
      case 'PATIENT_NOTIFIED':
      case 'PATIENT_ACK':
        return 1;
      case 'SPECIALIST_REFERRED':
      case 'REFERRAL_ACCEPTED':
        return 2;
      case 'PROCEDURE_DONE':
        return 3;
      case 'CLOSED_LOOP':
        return 4;
      default:
        return 0;
    }
  };

  const currentStepIdx = getActiveStepIndex();

  return (
    <div className="w-full max-w-xl mx-auto my-6" dir={t.dir}>
      {/* Mock Mobile View Wrapper */}
      <div className="bg-slate-900 rounded-[2.5rem] p-3 shadow-2xl border-4 border-slate-800">
        <div className="bg-white rounded-[2rem] overflow-hidden min-h-[640px] flex flex-col">

          {/* Top Bar */}
          <div className="bg-gradient-to-r from-teal-700 to-teal-900 text-white p-5 pt-8">
            <div className="flex items-center justify-between mb-3">
              <span className="text-[11px] font-semibold bg-white/20 backdrop-blur-sm px-2.5 py-1 rounded-full uppercase tracking-wider">
                {t.badge}
              </span>
              <button
                onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')}
                className="flex items-center gap-1 text-xs bg-white/10 hover:bg-white/20 px-2.5 py-1 rounded-full transition-colors"
              >
                <Globe2 className="w-3.5 h-3.5" />
                <span>{lang === 'ar' ? 'English' : 'عربي'}</span>
              </button>
            </div>

            <h2 className="text-xl font-bold">{t.greeting}</h2>
            <p className="text-xs text-teal-100 mt-1">{t.subtitle}</p>

            {/* Episode Selector for Demo purposes */}
            <div className="mt-3 pt-3 border-t border-teal-600/50 flex items-center justify-between text-xs" dir="ltr">
              <span className="text-teal-200 font-medium">Demo Case File:</span>
              <select
                value={activeEpisodeId}
                onChange={(e) => {
                  setActiveEpisodeId(e.target.value);
                  setCallbackRequested(false);
                }}
                className="bg-teal-800 text-white text-xs rounded px-2.5 py-1 border border-teal-500 focus:outline-none cursor-pointer"
              >
                {episodes.map((ep) => (
                  <option key={ep.id} value={ep.id}>
                    {ep.id} — {ep.patientName}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="p-5 flex-1 space-y-5 overflow-y-auto">
            {/* Reassurance Card */}
            <div className="p-4 rounded-2xl bg-teal-50 border border-teal-100 text-teal-950">
              <div className="flex items-center gap-2 font-bold text-sm text-teal-900 mb-1">
                <Sparkles className="w-4 h-4 text-teal-600" />
                {t.reassuranceHeader}
              </div>
              <p className="text-xs leading-relaxed text-teal-800">
                {t.reassuranceBody}
              </p>
            </div>

            {/* Delivery-style Care Journey Tracker */}
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                {t.title}
              </h3>
              <div className="space-y-4 relative before:absolute before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200 before:start-[13px]">
                {t.steps.map((step, idx) => {
                  const isDone = idx < currentStepIdx || currentEp.stage === 'CLOSED_LOOP';
                  const isCurrent = idx === currentStepIdx && currentEp.stage !== 'CLOSED_LOOP';

                  return (
                    <div key={idx} className="flex items-start gap-3 relative">
                      <div className="z-10 mt-0.5">
                        {isDone ? (
                          <div className="w-7 h-7 rounded-full bg-teal-600 flex items-center justify-center text-white shadow-sm">
                            <CheckCircle2 className="w-4 h-4" />
                          </div>
                        ) : isCurrent ? (
                          <div className="w-7 h-7 rounded-full bg-amber-500 flex items-center justify-center text-white ring-4 ring-amber-100 shadow-sm animate-pulse">
                            <Circle className="w-3.5 h-3.5 fill-current" />
                          </div>
                        ) : (
                          <div className="w-7 h-7 rounded-full bg-slate-100 border border-slate-300 flex items-center justify-center text-slate-400">
                            <span className="text-[10px] font-bold">{idx + 1}</span>
                          </div>
                        )}
                      </div>

                      <div className="flex-1 pt-0.5">
                        <h4
                          className={`text-xs font-semibold ${isCurrent
                            ? 'text-amber-800 font-bold'
                            : isDone
                              ? 'text-slate-900'
                              : 'text-slate-400'
                            }`}
                        >
                          {step.label}
                        </h4>
                        <p className="text-[11px] text-slate-500 mt-0.5">{step.sub}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Accountable Clinician Contact Box */}
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-1">
              <span className="text-slate-500 font-medium">{t.doctorContact}</span>
              <p className="font-semibold text-slate-800">
                {currentEp.currentOwner.name} ({currentEp.currentOwner.role})
              </p>
              <p className="text-slate-500 text-[11px]">{currentEp.currentOwner.facility}</p>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2 pt-2">
              <button
                onClick={() => setCallbackRequested(true)}
                disabled={callbackRequested}
                className={`w-full py-2.5 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all ${callbackRequested
                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                  : 'bg-teal-700 hover:bg-teal-800 text-white shadow-sm'
                  }`}
              >
                <PhoneCall className="w-3.5 h-3.5" />
                {callbackRequested ? t.btnCallbackSuccess : t.btnCallback}
              </button>

              <button
                className="w-full py-2.5 px-3 rounded-xl text-xs font-semibold border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 flex items-center justify-center gap-2 transition-colors"
              >
                <Calendar className="w-3.5 h-3.5 text-slate-500" />
                {t.btnBook}
              </button>
            </div>

            {/* Closed Loop Status Banner */}
            {currentEp.stage === 'CLOSED_LOOP' && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-center space-y-1">
                <span className="text-xs font-bold text-emerald-800 flex items-center justify-center gap-1">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  {lang === 'ar' ? 'اكتملت دائرة الرعاية بنجاح' : 'Care Loop Confirmed Closed'}
                </span>
                <p className="text-[11px] text-emerald-700">
                  {lang === 'ar'
                    ? 'تم تسجيل كافة الفحوصات التأكيدية وتحديث ملفك الصحي الوقائي.'
                    : 'All confirmatory findings have been documented and certified by your doctor.'}
                </p>
              </div>
            )}

          </div>
        </div>
      </div>
    </div>
  );
};

