'use client';

import React from 'react';
import { useEpisodes } from '@/context/EpisodeContext';
import { CaseStage } from '@/types/halqa';
import { 
  AlertCircle, 
  Clock, 
  ArrowRight, 
  CheckCircle2, 
  UserCheck 
} from 'lucide-react';

const COLUMNS: { stage: CaseStage; label: string; sub: string }[] = [
  { stage: 'INGESTED', label: '1. Ingested & Triage', sub: 'Malaffi feed / New finding' },
  { stage: 'PATIENT_NOTIFIED', label: '2. Patient Contacted', sub: 'Empathetic outreach active' },
  { stage: 'SPECIALIST_REFERRED', label: '3. Handshake & Referral', sub: 'Cross-provider dispatch' },
  { stage: 'PROCEDURE_DONE', label: '4. Confirmatory Procedure', sub: 'Biopsy / Diagnostic done' },
  { stage: 'CLOSED_LOOP', label: '5. Documented Closure', sub: 'Verified by Physician' },
];

export const KanbanBoard: React.FC = () => {
  const { episodes, setSelectedEpisode, advanceStage } = useEpisodes();

  const getSlaBadge = (hours: number, stage: CaseStage) => {
    if (stage === 'CLOSED_LOOP') {
      return (
        <span className="flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
          <CheckCircle2 className="w-3 h-3" /> SLA Met
        </span>
      );
    }
    if (hours <= 12) {
      return (
        <span className="flex items-center gap-1 text-xs font-bold px-2 py-0.5 rounded bg-rose-100 text-rose-700 animate-pulse border border-rose-300">
          <AlertCircle className="w-3 h-3" /> {hours}h left (Urgent)
        </span>
      );
    }
    if (hours <= 24) {
      return (
        <span className="flex items-center gap-1 text-xs font-medium px-2 py-0.5 rounded bg-amber-100 text-amber-800">
          <Clock className="w-3 h-3" /> {hours}h left
        </span>
      );
    }
    return (
      <span className="flex items-center gap-1 text-xs font-medium px-2 py-0.5 rounded bg-slate-100 text-slate-700">
        <Clock className="w-3 h-3" /> {hours}h remaining
      </span>
    );
  };

  const nextStageMap: Partial<Record<CaseStage, CaseStage>> = {
    INGESTED: 'PATIENT_NOTIFIED',
    PATIENT_NOTIFIED: 'SPECIALIST_REFERRED',
    SPECIALIST_REFERRED: 'PROCEDURE_DONE',
    PROCEDURE_DONE: 'CLOSED_LOOP',
  };

  return (
    <div className="w-full overflow-x-auto pb-4">
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4 min-w-[1100px]">
        {COLUMNS.map((col) => {
          const colEpisodes = episodes.filter((ep) => ep.stage === col.stage);

          return (
            <div
              key={col.stage}
              className="bg-slate-50 border border-slate-200 rounded-xl p-3 flex flex-col min-h-[520px]"
            >
              <div className="border-b border-slate-200 pb-2 mb-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-slate-800 text-sm">{col.label}</h3>
                  <span className="text-xs bg-slate-200 text-slate-700 px-2 py-0.5 rounded-full font-mono">
                    {colEpisodes.length}
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5">{col.sub}</p>
              </div>

              <div className="flex-1 space-y-3">
                {colEpisodes.map((ep) => (
                  <div
                    key={ep.id}
                    onClick={() => setSelectedEpisode(ep)}
                    className="bg-white border border-slate-200 hover:border-teal-500 rounded-lg p-3 shadow-sm hover:shadow-md transition-all cursor-pointer group"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-mono font-bold text-teal-800 bg-teal-50 px-2 py-0.5 rounded border border-teal-200">
                        {ep.id}
                      </span>
                      {getSlaBadge(ep.slaHoursRemaining, ep.stage)}
                    </div>

                    <h4 className="font-semibold text-slate-900 text-sm leading-tight">
                      {ep.patientName}
                    </h4>
                    <p className="text-xs text-slate-500 font-mono mt-0.5">
                      {ep.patientPhone}
                    </p>

                    <div className="my-2 p-2 bg-slate-50 rounded border border-slate-100 text-xs">
                      <span className="font-medium text-slate-700 block line-clamp-2">
                        {ep.testFinding}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 text-xs text-slate-600 mt-2">
                      <UserCheck className="w-3.5 h-3.5 text-slate-400" />
                      <span className="truncate">{ep.currentOwner.name}</span>
                    </div>

                    {nextStageMap[ep.stage] && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          advanceStage(ep.id, nextStageMap[ep.stage]!);
                        }}
                        className="w-full mt-3 py-1.5 px-2 bg-slate-100 hover:bg-teal-600 hover:text-white text-slate-700 rounded text-xs font-medium flex items-center justify-center gap-1.5 transition-colors"
                      >
                        Advance Stage <ArrowRight className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                ))}

                {colEpisodes.length === 0 && (
                  <div className="h-32 border-2 border-dashed border-slate-200 rounded-lg flex items-center justify-center text-xs text-slate-400">
                    No active cases
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

