'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { ScreeningEpisode, CaseStage, ScreeningType } from '@/types/halqa';
import { initialEpisodes } from '@/data/mockEpisodes';

interface EpisodeContextType {
  episodes: ScreeningEpisode[];
  selectedEpisode: ScreeningEpisode | null;
  activePatientEpisodeId: string;
  setActivePatientEpisodeId: (id: string) => void;
  setSelectedEpisode: (episode: ScreeningEpisode | null) => void;
  advanceStage: (id: string, nextStage: CaseStage, note?: string) => void;
  reassignOwner: (id: string, newOwnerName: string, newFacility: string) => void;
  closeCaseWithProof: (
    id: string,
    proof: {
      procedureType: string;
      pathologyVerdict: string;
      signedByDr: string;
      surveillancePlan: string;
    }
  ) => void;
  ingestRandomLabResult: () => void;
}

const EpisodeContext = createContext<EpisodeContextType | undefined>(undefined);

export const EpisodeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [episodes, setEpisodes] = useState<ScreeningEpisode[]>(initialEpisodes);
  const [selectedEpisode, setSelectedEpisode] = useState<ScreeningEpisode | null>(null);
  const [activePatientEpisodeId, setActivePatientEpisodeId] = useState<string>(initialEpisodes[0].id);

  // Live countdown ticker simulation for realism
  useEffect(() => {
    const timer = setInterval(() => {
      setEpisodes((prev) =>
        prev.map((ep) => {
          if (ep.stage === 'CLOSED_LOOP' || ep.slaHoursRemaining <= 0) return ep;
          // Decrement SLA slightly for realism
          return ep;
        })
      );
    }, 10000);
    return () => clearInterval(timer);
  }, []);

  const advanceStage = (id: string, nextStage: CaseStage, note?: string) => {
    setEpisodes((prev) =>
      prev.map((ep) => {
        if (ep.id !== id) return ep;
        const updated: ScreeningEpisode = {
          ...ep,
          stage: nextStage,
          auditTrail: [
            ...ep.auditTrail,
            {
              timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
              action: `Transitioned status to ${nextStage}`,
              actor: 'Clinician / System Orchestrator',
              note: note || undefined,
            },
          ],
        };
        if (selectedEpisode?.id === id) setSelectedEpisode(updated);
        return updated;
      })
    );
  };

  const reassignOwner = (id: string, newOwnerName: string, newFacility: string) => {
    setEpisodes((prev) =>
      prev.map((ep) => {
        if (ep.id !== id) return ep;
        const updated: ScreeningEpisode = {
          ...ep,
          currentOwner: {
            ...ep.currentOwner,
            name: newOwnerName,
            facility: newFacility,
          },
          auditTrail: [
            ...ep.auditTrail,
            {
              timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
              action: `Custody transferred to ${newOwnerName} (${newFacility})`,
              actor: 'Lead Coordinator',
            },
          ],
        };
        if (selectedEpisode?.id === id) setSelectedEpisode(updated);
        return updated;
      })
    );
  };

  const closeCaseWithProof = (
    id: string,
    proof: {
      procedureType: string;
      pathologyVerdict: string;
      signedByDr: string;
      surveillancePlan: string;
    }
  ) => {
    setEpisodes((prev) =>
      prev.map((ep) => {
        if (ep.id !== id) return ep;
        const updated: ScreeningEpisode = {
          ...ep,
          stage: 'CLOSED_LOOP',
          slaHoursRemaining: 0,
          closureProof: {
            ...proof,
            signedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
          },
          auditTrail: [
            ...ep.auditTrail,
            {
              timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
              action: `Clinical Loop Closure Verified by ${proof.signedByDr}`,
              actor: proof.signedByDr,
              note: `Verdict: ${proof.pathologyVerdict} | Plan: ${proof.surveillancePlan}`,
            },
          ],
        };
        if (selectedEpisode?.id === id) setSelectedEpisode(updated);
        return updated;
      })
    );
  };

  const ingestRandomLabResult = () => {
    const randomId = `EP-UAE-${Math.floor(1000 + Math.random() * 9000)}`;
    const newEp: ScreeningEpisode = {
      id: randomId,
      patientId: `PT-${Math.floor(1000 + Math.random() * 9000)}`,
      patientName: 'Zayed Al Dhaheri',
      patientPhone: '+971 50 *** 7721',
      preferredLanguage: 'ar',
      screeningType: 'COLORECTAL_FIT',
      testFinding: 'Automated Lab Flag: Positive FIT (>190 µg/g Hb)',
      urgency: 'CRITICAL',
      stage: 'INGESTED',
      slaHoursRemaining: 24,
      slaTotalHours: 24,
      currentOwner: {
        id: 'NAV-02',
        name: 'Nurse Ayesha (Triage)',
        role: 'NAVIGATOR',
        facility: 'Abu Dhabi Central Triage Hub',
      },
      auditTrail: [
        {
          timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
          action: 'HL7 FHIR DiagnosticReport Ingested via Malaffi Node',
          actor: 'Malaffi HIE Gateway',
        },
      ],
    };

    setEpisodes((prev) => [newEp, ...prev]);
    setActivePatientEpisodeId(randomId);
  };

  return (
    <EpisodeContext.Provider
      value={{
        episodes,
        selectedEpisode,
        activePatientEpisodeId,
        setActivePatientEpisodeId,
        setSelectedEpisode,
        advanceStage,
        reassignOwner,
        closeCaseWithProof,
        ingestRandomLabResult,
      }}
    >
      {children}
    </EpisodeContext.Provider>
  );
};

export const useEpisodes = () => {
  const context = useContext(EpisodeContext);
  if (!context) throw new Error('useEpisodes must be used within an EpisodeProvider');
  return context;
};
