'use client';

import React from 'react';
import { useEpisodes } from '@/context/EpisodeContext';
import { 
  TrendingDown, 
  ShieldCheck, 
  Clock, 
  AlertTriangle, 
  Activity, 
  Building2, 
  ArrowUpRight 
} from 'lucide-react';

export const AnalyticsView: React.FC = () => {
  const { episodes } = useEpisodes();

  const totalCases = episodes.length;
  const closedCases = episodes.filter((e) => e.stage === 'CLOSED_LOOP').length;
  const urgentBreachRisk = episodes.filter(
    (e) => e.stage !== 'CLOSED_LOOP' && e.slaHoursRemaining <= 12
  ).length;

  return (
    <div className="w-full max-w-6xl mx-auto space-y-6 py-4">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-teal-950 to-slate-900 text-white rounded-2xl p-6 shadow-md border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-teal-400 text-xs font-semibold uppercase tracking-wider">
            <Activity className="w-4 h-4" /> Abu Dhabi Healthcare Network • Malaffi Surveillance Node
          </div>
          <h2 className="text-2xl font-bold mt-1">Diagnostic Loop Closure Intelligence</h2>
          <p className="text-slate-400 text-xs mt-1">
            Real-time population health monitoring across SEHA, Cleveland Clinic Abu Dhabi, and private clinics.
          </p>
        </div>
        <div className="flex items-center gap-2 bg-slate-800/80 border border-slate-700 px-3 py-2 rounded-xl text-xs">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-slate-300">Live Pilot Node: <strong>Active</strong></span>
        </div>
      </div>

      {/* Primary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* KPI 1 */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-medium">Mean Time to Confirmatory Care</span>
            <span className="p-1.5 bg-emerald-50 text-emerald-700 rounded-lg">
              <TrendingDown className="w-4 h-4" />
            </span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-slate-900">4.2 Days</span>
            <span className="text-xs font-semibold text-emerald-600 flex items-center">
              -85% vs baseline
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            Historical baseline: 28.5 days before automated state machine.
          </p>
        </div>

        {/* KPI 2 */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-medium">Documented Closure Rate</span>
            <span className="p-1.5 bg-teal-50 text-teal-700 rounded-lg">
              <ShieldCheck className="w-4 h-4" />
            </span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-slate-900">94.8%</span>
            <span className="text-xs font-semibold text-teal-600 flex items-center">
              +58% gain
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            {closedCases} of {totalCases} simulated cases locked with signed proof.
          </p>
        </div>

        {/* KPI 3 */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-medium">Referral Handshake Acceptance</span>
            <span className="p-1.5 bg-sky-50 text-sky-700 rounded-lg">
              <Clock className="w-4 h-4" />
            </span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-slate-900">98.2%</span>
            <span className="text-xs font-semibold text-sky-600 flex items-center">
              &lt; 24h SLA
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            Two-way electronic confirmation between outpatient & specialists.
          </p>
        </div>

        {/* KPI 4 */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-medium">Critical SLA Escalations</span>
            <span className="p-1.5 bg-rose-50 text-rose-700 rounded-lg">
              <AlertTriangle className="w-4 h-4" />
            </span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-slate-900">{urgentBreachRisk}</span>
            <span className="text-xs font-semibold text-rose-600">Active alerts</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            Cases auto-escalated to regional care coordinators before breach.
          </p>
        </div>

      </div>

      {/* Detailed Tables & Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Screening Track Breakdown */}
        <div className="lg:col-span-2 bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <h3 className="font-bold text-slate-900 text-sm mb-1">
            Screening Program Conversion & Drop-off Prevention
          </h3>
          <p className="text-xs text-slate-500 mb-4">
            Comparison of screening categories across the Abu Dhabi health system.
          </p>

          <div className="space-y-4">
            
            {/* Row 1 */}
            <div>
              <div className="flex justify-between text-xs font-medium mb-1">
                <span className="text-slate-800">Colorectal Screening (FIT Positive &gt; 150 µg/g)</span>
                <span className="text-teal-700 font-bold">96% Closure Rate (Avg 3.8 days)</span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                <div className="bg-teal-600 h-2.5 rounded-full" style={{ width: '96%' }} />
              </div>
            </div>

            {/* Row 2 */}
            <div>
              <div className="flex justify-between text-xs font-medium mb-1">
                <span className="text-slate-800">Breast Cancer Screening (BI-RADS 3/4/5)</span>
                <span className="text-teal-700 font-bold">92% Closure Rate (Avg 4.9 days)</span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                <div className="bg-teal-600 h-2.5 rounded-full" style={{ width: '92%' }} />
              </div>
            </div>

            {/* Row 3 */}
            <div>
              <div className="flex justify-between text-xs font-medium mb-1">
                <span className="text-slate-800">Cardiometabolic Routine Screen (HbA1c &gt; 10%)</span>
                <span className="text-teal-700 font-bold">98% Closure Rate (Avg 2.1 days)</span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                <div className="bg-teal-600 h-2.5 rounded-full" style={{ width: '98%' }} />
              </div>
            </div>

            {/* Row 4 */}
            <div>
              <div className="flex justify-between text-xs font-medium mb-1">
                <span className="text-slate-800">Cervical Cytology & HPV Genotyping</span>
                <span className="text-teal-700 font-bold">91% Closure Rate (Avg 5.1 days)</span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                <div className="bg-teal-600 h-2.5 rounded-full" style={{ width: '91%' }} />
              </div>
            </div>

          </div>

          <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Data synced via HL7 FHIR Task & DiagnosticReport resources</span>
            <span className="text-teal-700 font-medium flex items-center gap-1 cursor-pointer hover:underline">
              Export FHIR Metric Audit <ArrowUpRight className="w-3.5 h-3.5" />
            </span>
          </div>
        </div>

        {/* Network Facility Connectivity Card */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="font-bold text-slate-900 text-sm mb-1">Connected Network Nodes</h3>
            <p className="text-xs text-slate-500 mb-4">
              Cross-provider custody handshakes active in current cluster.
            </p>

            <div className="space-y-3">
              <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-lg border border-slate-100 text-xs">
                <div className="flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-slate-500" />
                  <span className="font-medium text-slate-800">Cleveland Clinic Abu Dhabi</span>
                </div>
                <span className="text-emerald-700 font-bold">Synced</span>
              </div>

              <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-lg border border-slate-100 text-xs">
                <div className="flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-slate-500" />
                  <span className="font-medium text-slate-800">SEHA Sheikh Shakhbout (SSMC)</span>
                </div>
                <span className="text-emerald-700 font-bold">Synced</span>
              </div>

              <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-lg border border-slate-100 text-xs">
                <div className="flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-slate-500" />
                  <span className="font-medium text-slate-800">Tawam Hospital Oncology</span>
                </div>
                <span className="text-emerald-700 font-bold">Synced</span>
              </div>

              <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-lg border border-slate-100 text-xs">
                <div className="flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-slate-500" />
                  <span className="font-medium text-slate-800">Imperial College London (ICLDC)</span>
                </div>
                <span className="text-emerald-700 font-bold">Synced</span>
              </div>
            </div>
          </div>

          <div className="mt-4 p-3 bg-teal-50 border border-teal-200 rounded-lg text-xs text-teal-900">
            <span className="font-bold block mb-0.5">Zero-Drop Guarantee</span>
            Cases without an acknowledged specialist within 48h escalate automatically to the central DoH triage bureau.
          </div>
        </div>

      </div>

    </div>
  );
};

