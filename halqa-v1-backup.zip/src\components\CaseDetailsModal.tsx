'use client';

import React, { useState } from 'react';
import { useEpisodes } from '@/context/EpisodeContext';
import { 
  X, ShieldCheck, User, Building2, History, Lock, FileText 
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const CaseDetailsModal: React.FC = () => {
  const { selectedEpisode, setSelectedEpisode, reassignOwner, closeCaseWithProof } = useEpisodes();
  const [showClosureForm, setShowClosureForm] = useState(false);
  const [showTransferForm, setShowTransferForm] = useState(false);

  const [newOwner, setNewOwner] = useState('Dr. Reem Al Hashimi');
  const [newFacility, setNewFacility] = useState('Cleveland Clinic Abu Dhabi');
  const [procedureType, setProcedureType] = useState('Diagnostic Colonoscopy with Polypectomy');
  const [pathologyVerdict, setPathologyVerdict] = useState('Tubulovillous adenoma with low-grade dysplasia. Complete excision confirmed.');
  const [signedByDr, setSignedByDr] = useState('Dr. Tariq Al Nuaimi (DOH-9021)');
  const [surveillancePlan, setSurveillancePlan] = useState('Repeat colonoscopy in 3 years per Abu Dhabi colorectal guidelines.');

  if (!selectedEpisode) return null;

  const downloadFhirJson = () => {
    const fhirBundle = {
      resourceType: 'Bundle',
      type: 'collection',
      id: `fhir-${selectedEpisode.id}`,
      entry: [
        {
          resource: {
            resourceType: 'Patient',
            id: selectedEpisode.patientId,
            name: [{ text: selectedEpisode.patientName }],
            telecom: [{ system: 'phone', value: selectedEpisode.patientPhone }]
          }
        },
        {
          resource: {
            resourceType: 'DiagnosticReport',
            id: `rep-${selectedEpisode.id}`,
            status: selectedEpisode.stage === 'CLOSED_LOOP' ? 'final' : 'preliminary',
            code: { text: selectedEpisode.screeningType },
            conclusion: selectedEpisode.testFinding
          }
        },
        {
          resource: {
            resourceType: 'Task',
            id: `task-${selectedEpisode.id}`,
            status: selectedEpisode.stage === 'CLOSED_LOOP' ? 'completed' : 'in-progress',
            owner: {
              display: `${selectedEpisode.currentOwner.name} - ${selectedEpisode.currentOwner.facility}`
            }
          }
        }
      ]
    };

    const blob = new Blob([JSON.stringify(fhirBundle, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${selectedEpisode.id}-FHIR-bundle.json`;
    a.click();
  };

  const handleCloseCase = (e: React.FormEvent) => {
    e.preventDefault();
    closeCaseWithProof(selectedEpisode.id, {
      procedureType,
      pathologyVerdict,
      signedByDr,
      surveillancePlan,
    });
    setShowClosureForm(false);
    confetti({ particleCount: 70, spread: 60, origin: { y: 0.6 } });
  };

  const handleTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    reassignOwner(selectedEpisode.id, newOwner, newFacility);
    setShowTransferForm(false);
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200">
        
        <div className="flex items-center justify-between p-6 border-b border-slate-100 bg-slate-50/50">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono font-bold text-teal-800 bg-teal-100 px-2.5 py-0.5 rounded text-xs">
                {selectedEpisode.id}
              </span>
              <span className="text-xs font-medium px-2 py-0.5 rounded bg-slate-200 text-slate-700">
                {selectedEpisode.screeningType}
              </span>
            </div>
            <h2 className="text-xl font-bold text-slate-900 mt-1">
              {selectedEpisode.patientName}
            </h2>
          </div>
          
          <div className="flex items-center gap-2">
            <button
              onClick={downloadFhirJson}
              className="px-2.5 py-1.5 text-xs font-semibold text-teal-700 bg-teal-50 hover:bg-teal-100 rounded-lg border border-teal-200 transition-colors flex items-center gap-1.5 shadow-sm cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5" />
              Export FHIR
            </button>
            <button
              onClick={() => setSelectedEpisode(null)}
              className="p-2 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="p-6 space-y-6">
          <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-900">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-800 block mb-1">
              Screening Finding
            </span>
            <p className="font-semibold">{selectedEpisode.testFinding}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 rounded-xl border border-slate-200 bg-slate-50">
            <div>
              <span className="text-xs text-slate-500 block">Current Accountable Clinician</span>
              <div className="flex items-center gap-2 mt-1">
                <User className="w-4 h-4 text-teal-600" />
                <span className="font-semibold text-slate-800 text-sm">
                  {selectedEpisode.currentOwner.name} ({selectedEpisode.currentOwner.role})
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5 flex items-center gap-1">
                <Building2 className="w-3 h-3" /> {selectedEpisode.currentOwner.facility}
              </p>
            </div>

            <div className="flex items-center md:justify-end">
              <button
                onClick={() => setShowTransferForm(!showTransferForm)}
                className="text-xs font-medium text-teal-700 bg-teal-50 hover:bg-teal-100 border border-teal-200 px-3 py-2 rounded-lg transition-colors cursor-pointer"
              >
                Transfer / Handshake Custody
              </button>
            </div>
          </div>

          {showTransferForm && (
            <form onSubmit={handleTransfer} className="p-4 rounded-xl border border-teal-200 bg-teal-50/50 space-y-3">
              <h4 className="text-xs font-bold uppercase text-teal-900">Transfer Case Ownership</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-600 block mb-1">Receiving Specialist</label>
                  <input type="text" value={newOwner} onChange={(e) => setNewOwner(e.target.value)} className="w-full text-xs p-2 border border-slate-300 rounded bg-white text-slate-900" />
                </div>
                <div>
                  <label className="text-xs text-slate-600 block mb-1">Receiving Facility</label>
                  <input type="text" value={newFacility} onChange={(e) => setNewFacility(e.target.value)} className="w-full text-xs p-2 border border-slate-300 rounded bg-white text-slate-900" />
                </div>
              </div>
              <button type="submit" className="text-xs font-semibold px-3 py-1.5 bg-teal-700 text-white rounded hover:bg-teal-800 transition-colors cursor-pointer">
                Confirm Digital Handshake
              </button>
            </form>
          )}

          {selectedEpisode.stage === 'CLOSED_LOOP' && selectedEpisode.closureProof ? (
            <div className="p-5 rounded-xl border border-emerald-300 bg-emerald-50/70 space-y-3">
              <div className="flex items-center gap-2 text-emerald-800 font-bold text-sm">
                <ShieldCheck className="w-5 h-5 text-emerald-600" /> Verified Clinical Closure
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-slate-700">
                <div><span className="font-semibold block text-slate-900">Procedure:</span> {selectedEpisode.closureProof.procedureType}</div>
                <div><span className="font-semibold block text-slate-900">Signed Off By:</span> {selectedEpisode.closureProof.signedByDr} ({selectedEpisode.closureProof.signedAt})</div>
                <div className="col-span-2"><span className="font-semibold block text-slate-900">Pathology Verdict:</span> {selectedEpisode.closureProof.pathologyVerdict}</div>
                <div className="col-span-2"><span className="font-semibold block text-slate-900">Surveillance Plan:</span> {selectedEpisode.closureProof.surveillancePlan}</div>
              </div>
            </div>
          ) : (
            <div className="p-4 rounded-xl border border-slate-200 bg-white">
              {!showClosureForm ? (
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h4 className="font-semibold text-sm text-slate-900 flex items-center gap-1.5">
                      <Lock className="w-4 h-4 text-slate-500" /> Proof-of-Closure Gate
                    </h4>
                    <p className="text-xs text-slate-500 mt-0.5">Cases cannot be closed without signed clinical proof.</p>
                  </div>
                  <button onClick={() => setShowClosureForm(true)} className="px-3 py-2 text-xs font-semibold bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors shrink-0 cursor-pointer">
                    Execute Clinical Closure
                  </button>
                </div>
              ) : (
                <form onSubmit={handleCloseCase} className="space-y-3">
                  <h4 className="font-bold text-sm text-slate-900 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" /> Enter Verified Closure Evidence
                  </h4>
                  <div className="space-y-2 text-xs">
                    <div><label className="font-medium text-slate-700 block mb-1">Confirmatory Procedure</label><input type="text" value={procedureType} onChange={(e) => setProcedureType(e.target.value)} className="w-full p-2 border border-slate-300 rounded text-slate-900" required /></div>
                    <div><label className="font-medium text-slate-700 block mb-1">Pathology / Diagnostic Verdict</label><textarea value={pathologyVerdict} onChange={(e) => setPathologyVerdict(e.target.value)} className="w-full p-2 border border-slate-300 rounded text-slate-900" rows={2} required /></div>
                    <div><label className="font-medium text-slate-700 block mb-1">Documented Surveillance Plan</label><input type="text" value={surveillancePlan} onChange={(e) => setSurveillancePlan(e.target.value)} className="w-full p-2 border border-slate-300 rounded text-slate-900" required /></div>
                    <div><label className="font-medium text-slate-700 block mb-1">Physician Signature & License</label><input type="text" value={signedByDr} onChange={(e) => setSignedByDr(e.target.value)} className="w-full p-2 border border-slate-300 rounded text-slate-900" required /></div>
                  </div>
                  <div className="flex justify-end gap-2 pt-2">
                    <button type="button" onClick={() => setShowClosureForm(false)} className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded cursor-pointer">Cancel</button>
                    <button type="submit" className="px-4 py-1.5 text-xs font-semibold bg-emerald-600 text-white rounded hover:bg-emerald-700 cursor-pointer">Sign & Lock Case Closure</button>
                  </div>
                </form>
              )}
            </div>
          )}

          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3 flex items-center gap-1.5"><History className="w-3.5 h-3.5" /> Immutable Audit Trail</h4>
            <div className="space-y-3 border-l-2 border-slate-200 pl-4 ml-2">
              {selectedEpisode.auditTrail.map((item, idx) => (
                <div key={idx} className="relative text-xs">
                  <div className="absolute -left-[21px] top-1 w-2.5 h-2.5 rounded-full bg-teal-600 ring-4 ring-white" />
                  <span className="font-mono text-slate-400 text-[10px] block">{item.timestamp}</span>
                  <span className="font-medium text-slate-800">{item.action}</span>
                  <span className="text-slate-500 block text-[11px] mt-0.5">By: {item.actor}</span>
                  {item.note && <div className="mt-1 p-2 bg-slate-100 rounded text-slate-700 text-[11px] font-mono">{item.note}</div>}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
