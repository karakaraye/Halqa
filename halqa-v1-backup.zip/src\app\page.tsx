'use client';

import React, { useState } from 'react';
import { EpisodeProvider, useEpisodes } from '@/context/EpisodeContext';
import { Header } from '@/components/Header';
import { KanbanBoard } from '@/components/KanbanBoard';
import { CaseDetailsModal } from '@/components/CaseDetailsModal';
import { PatientPortalView } from '@/components/PatientPortalView';
import { AnalyticsView } from '@/components/AnalyticsView';
import { PlusCircle } from 'lucide-react';

function DashboardContent() {
  const [activeTab, setActiveTab] = useState<'kanban' | 'patient' | 'analytics'>('kanban');
  const { ingestRandomLabResult, episodes } = useEpisodes();

  const urgentCount = episodes.filter(
    (e) => e.stage !== 'CLOSED_LOOP' && e.slaHoursRemaining <= 12
  ).length;

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-900 flex flex-col font-sans">
      <Header activeTab={activeTab} setActiveTab={setActiveTab} />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'kanban' && (
          <div className="space-y-4">
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  Active Screening Episodes & Diagnostic Pipeline
                  <span className="text-xs bg-slate-100 text-slate-600 font-normal px-2.5 py-0.5 rounded-full border border-slate-200">
                    {episodes.length} Total Cases
                  </span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Track post-screening findings, monitor countdown SLAs, and enforce verified clinical closure.
                </p>
              </div>

              <div className="flex items-center gap-3">
                {urgentCount > 0 && (
                  <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-50 text-rose-700 text-xs font-semibold border border-rose-200">
                    <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                    {urgentCount} Critical SLA Alert{urgentCount > 1 ? 's' : ''}
                  </span>
                )}

                <button
                  onClick={ingestRandomLabResult}
                  className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-teal-700 hover:bg-teal-800 text-white text-xs font-semibold shadow-sm transition-all active:scale-95 cursor-pointer"
                >
                  <PlusCircle className="w-3.5 h-3.5" />
                  <span>Simulate Malaffi Result</span>
                </button>
              </div>
            </div>

            <KanbanBoard />
          </div>
        )}

        {activeTab === 'patient' && (
          <div className="space-y-4">
            <div className="text-center max-w-lg mx-auto">
              <h2 className="text-lg font-bold text-slate-900">
                Citizen Mobile Reassurance Experience
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Empathetic, non-stigmatizing delivery-style tracker in Arabic and English with 1-click coordinator access.
              </p>
            </div>

            <PatientPortalView />
          </div>
        )}

        {activeTab === 'analytics' && <AnalyticsView />}
      </main>

      <CaseDetailsModal />

      <footer className="border-t border-slate-200 bg-white py-4 text-center text-xs text-slate-500">
        <p>
          Halqa (حَلْقَة) • Built for the Abu Dhabi Future Health Digital Innovation Challenge 2026
        </p>
      </footer>
    </div>
  );
}

export default function Home() {
  return (
    <EpisodeProvider>
      <DashboardContent />
    </EpisodeProvider>
  );
}
