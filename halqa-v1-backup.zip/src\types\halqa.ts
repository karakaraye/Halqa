export type CaseStage =
  | 'INGESTED'            // Result received from lab / Malaffi HIE
  | 'PATIENT_NOTIFIED'    // Patient received empathetic communication
  | 'PATIENT_ACK'         // Patient acknowledged / booked consultation
  | 'SPECIALIST_REFERRED' // Cross-provider referral dispatched
  | 'REFERRAL_ACCEPTED'   // Specialist accepted custody
  | 'PROCEDURE_DONE'      // Confirmatory test (biopsy, colonoscopy, etc.)
  | 'CLOSED_LOOP';        // Human-governed clinical proof of closure

export type UrgencyLevel = 'CRITICAL' | 'ELEVATED' | 'ROUTINE';

export type ScreeningType = 
  | 'COLORECTAL_FIT' 
  | 'MAMMOGRAM_BIRADS' 
  | 'CERVICAL_CYTOLOGY' 
  | 'METABOLIC_HBA1C';

export interface ScreeningEpisode {
  id: string; // e.g. "EP-2026-0491"
  patientId: string;
  patientName: string;
  patientPhone: string;
  preferredLanguage: 'ar' | 'en';
  screeningType: ScreeningType;
  testFinding: string; // e.g. "Positive (185 µg/g Hb)" or "BI-RADS 4A Suspicious"
  urgency: UrgencyLevel;
  stage: CaseStage;
  slaHoursRemaining: number;
  slaTotalHours: number;
  currentOwner: {
    id: string;
    name: string;
    role: 'PCP' | 'NAVIGATOR' | 'SPECIALIST';
    facility: string; // e.g., "Al Bateen Healthcare Center"
  };
  destinationFacility?: string; // e.g., "Cleveland Clinic Abu Dhabi"
  auditTrail: {
    timestamp: string;
    action: string;
    actor: string;
    note?: string;
  }[];
  closureProof?: {
    documentUrl?: string;
    procedureType: string;
    pathologyVerdict: string;
    signedByDr: string;
    signedAt: string;
    surveillancePlan: string;
  };
}

