import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Halqa (حلقة) | Abu Dhabi Closed-Loop Diagnostic Orchestrator',
  description: 'Closed-loop diagnostic tracking and patient care orchestration across Malaffi, SEHA, and CCAD.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}

