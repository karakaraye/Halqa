import { ScreeningEpisode } from '@/types/halqa';

export const initialEpisodes: ScreeningEpisode[] = [
  {
    id: 'EP-UAE-1092',
    patientId: 'PT-8831',
    patientName: 'Sultan Al Mansoori',
    patientPhone: '+971 50 *** 4192',
    preferredLanguage: 'ar',
    screeningType: 'COLORECTAL_FIT',
    testFinding: 'Fecal Immunochemical Test: Positive (>200 µg/g Hb)',
    urgency: 'CRITICAL',
    stage: 'SPECIALIST_REFERRED',
    slaHoursRemaining: 18,
    slaTotalHours: 48,
    currentOwner: {
      id: 'DR-04',
      name: 'Dr. Mariam Al Zaabi',
      role: 'PCP',
      facility: 'Al Bateen Healthcare Center'
    },
    destinationFacility: 'Cleveland Clinic Abu Dhabi (Gastroenterology)',
    auditTrail: [
      { timestamp: '2026-11-04 09:15', action: 'Result Ingested via Malaffi Lab Node', actor: 'System' },
      { timestamp: '2026-11-04 11:30', action: 'Patient Reassurance SMS & App Notification Sent', actor: 'Automated Bot' },
      { timestamp: '2026-11-04 14:10', action: 'Patient Acknowledged & Requested Tele-Consult', actor: 'Sultan Al Mansoori' },
      { timestamp: '2026-11-05 10:00', action: 'Tele-Consult Completed; Expedited Colonoscopy Referral Issued', actor: 'Dr. Mariam Al Zaabi' }
    ]
  },
  {
    id: 'EP-UAE-2041',
    patientId: 'PT-3419',
    patientName: 'Fatima Al Kaabi',
    patientPhone: '+971 55 *** 8812',
    preferredLanguage: 'ar',
    screeningType: 'MAMMOGRAM_BIRADS',
    testFinding: 'Screening Mammogram: BI-RADS 4A (Low Suspicion of Malignancy)',
    urgency: 'CRITICAL',
    stage: 'INGESTED',
    slaHoursRemaining: 6,
    slaTotalHours: 24,
    currentOwner: {
      id: 'NAV-01',
      name: 'Nurse Reem (Central Triage)',
      role: 'NAVIGATOR',
      facility: 'Abu Dhabi Preventive Screening Hub'
    },
    destinationFacility: 'Sheikh Shakhbout Medical City (SSMC)',
    auditTrail: [
      { timestamp: '2026-11-06 02:30', action: 'Direct Diagnostic Feed Received', actor: 'Malaffi HIE' }
    ]
  },
  {
    id: 'EP-UAE-3088',
    patientId: 'PT-9011',
    patientName: 'Omar Farooq',
    patientPhone: '+971 52 *** 1104',
    preferredLanguage: 'en',
    screeningType: 'METABOLIC_HBA1C',
    testFinding: 'Routine IFHAS Screen: HbA1c 11.4%, Fasting Glucose 240 mg/dL',
    urgency: 'ELEVATED',
    stage: 'PROCEDURE_DONE',
    slaHoursRemaining: 72,
    slaTotalHours: 96,
    currentOwner: {
      id: 'DR-12',
      name: 'Dr. Khaled Tammam',
      role: 'SPECIALIST',
      facility: 'Imperial College London Diabetes Centre (ICLDC)'
    },
    auditTrail: [
      { timestamp: '2026-10-28 08:00', action: 'Screening Report Ingested', actor: 'System' },
      { timestamp: '2026-10-29 11:00', action: 'Endocrinology Consultation Attended', actor: 'Omar Farooq' },
      { timestamp: '2026-11-03 14:00', action: 'Insulin Regimen Titrated & CGM Paired', actor: 'Dr. Khaled Tammam' }
    ]
  },
  {
    id: 'EP-UAE-4019',
    patientId: 'PT-5522',
    patientName: 'Noura Al Shamsi',
    patientPhone: '+971 50 *** 9033',
    preferredLanguage: 'ar',
    screeningType: 'MAMMOGRAM_BIRADS',
    testFinding: 'Diagnostic Core Needle Biopsy: Benign Fibroadenoma',
    urgency: 'ROUTINE',
    stage: 'CLOSED_LOOP',
    slaHoursRemaining: 0,
    slaTotalHours: 48,
    currentOwner: {
      id: 'DR-08',
      name: 'Dr. Huda Al Nuaimi',
      role: 'SPECIALIST',
      facility: 'Tawam Hospital Oncology'
    },
    auditTrail: [
      { timestamp: '2026-10-15 10:00', action: 'BI-RADS 4 Finding Ingested', actor: 'System' },
      { timestamp: '2026-10-20 12:00', action: 'Ultrasound Guided Core Biopsy Completed', actor: 'Tawam Hospital' },
      { timestamp: '2026-10-24 16:30', action: 'Closure Signed Off: Benign finding; return to 12-month routine screening', actor: 'Dr. Huda Al Nuaimi' }
    ],
    closureProof: {
      procedureType: 'Ultrasound-Guided Core Biopsy',
      pathologyVerdict: 'Benign Fibroadenoma. No atypia or malignancy.',
      signedByDr: 'Dr. Huda Al Nuaimi (License #DOH-5921)',
      signedAt: '2026-10-24 16:30',
      surveillancePlan: 'Re-enroll in standard IFHAS 12-month mammography recall.'
    }
  }
];

